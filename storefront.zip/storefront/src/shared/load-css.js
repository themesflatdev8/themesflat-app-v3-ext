export function loadStylesheetExtra() {
  let styleMain = document.getElementById("msell-stylesheet");
  if(!styleMain) return
  var head  = document.getElementsByTagName('head')[0];
  var link  = document.createElement('link');
  link.rel  = 'stylesheet';
  link.type = 'text/css';
  link.href = styleMain.getAttribute("href").replace("main.css", "final.css");
  head.appendChild(link);
}