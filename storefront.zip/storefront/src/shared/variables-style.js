export function getVariablesStyleBundle(settings) {
  if(!settings) return "" 
  return `
    --msell-card-background-color: ${settings.cardBackgroundColor};
    --msell-primary-color: ${settings.primaryColor};
    --msell-secondary-color: ${settings.secondaryColor};
    --msell-outstand-color: ${settings.outstandColor};
    --msell-border-radius: ${settings.borderRadius}px;
    --msell-border-color: ${settings.borderColor};
    --msell-image-fit: ${settings.imageFit};
  `
}

export function getVariablesStyleOffer(settings) {
  if(!settings) return "" 
  return `
    --msell-card-background-color: ${settings.cardBackgroundColor};
    --msell-primary-color: ${settings.primaryColor};
    --msell-secondary-color: ${settings.secondaryColor};
    --msell-outstand-color: ${settings.outstandColor};
    --msell-border-radius: ${settings.borderRadius}px;
    --msell-border-color: ${settings.borderColor};
  `
}