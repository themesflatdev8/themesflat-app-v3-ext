export const STORAGE_BUNDLE_COUNTDOWN_TIMER = "msb_countdown_timer"
export const STORAGE_VOLUME_DISCOUNT_COUNTDOWN_TIMER = "msv_countdown_timer"