export const _product1 = {
  "id": 9711268397331,
  "store_id": 90845675795,
  "title": "The Videographer Snowboard",
  "handle": "the-videographer-snowboard",
  "image": "https://cdn.shopify.com/s/files/1/0908/4567/5795/files/Main.jpg?v=1729080387",
  "price": 886,
  "compare_at_price": null,
  "available": "1",
  "stock": 50,
  "inventory_management": "shopify",
  "status": "active",
  "requires_selling_plan": 0,
  "created_at": "2024-10-16T12:06:25.000000Z",
  "updated_at": "2024-10-17T06:17:10.000000Z",
  "variants": [
    {
      "id": 49928935178515,
      "store_id": 90845675795,
      "product_id": 9711268397331,
      "title": "Default Title",
      "option1": "Default Title",
      "option2": null,
      "option3": null,
      "image": null,
      "inventory": 50,
      "inventory_management": "shopify",
      "price": 886,
      "compare_at_price": null,
      "created_at": "2024-10-17T06:17:10.000000Z",
      "updated_at": "2024-10-17T06:17:10.000000Z"
    }
  ],
  "options": [
    {
      "id": 12173539541267,
      "store_id": 90845675795,
      "product_id": 9711268397331,
      "name": "Title",
      "values": [
        "Default Title"
      ],
      "created_at": "2024-10-17T06:17:11.000000Z",
      "updated_at": "2024-10-17T06:17:11.000000Z"
    }
  ]
}

export const _product2 = {
  "id": 9711268495635,
  "store_id": 90845675795,
  "title": "The Complete Snowboard",
  "handle": "the-complete-snowboard",
  "image": "https://cdn.shopify.com/s/files/1/0908/4567/5795/files/Main_589fc064-24a2-4236-9eaf-13b2bd35d21d.jpg?v=1729080387",
  "price": 700,
  "compare_at_price": null,
  "available": "1",
  "stock": 50,
  "inventory_management": "shopify",
  "status": "active",
  "requires_selling_plan": 0,
  "created_at": "2024-10-16T12:06:27.000000Z",
  "updated_at": "2024-10-17T06:17:10.000000Z",
  "variants": [
      {
          "id": 49928935375123,
          "store_id": 90845675795,
          "product_id": 9711268495635,
          "title": "Ice",
          "option1": "Ice",
          "option2": null,
          "option3": null,
          "image": null,
          "inventory": 10,
          "inventory_management": "shopify",
          "price": 700,
          "compare_at_price": null,
          "created_at": "2024-10-17T06:17:10.000000Z",
          "updated_at": "2024-10-17T06:17:10.000000Z"
      },
      {
          "id": 49928935407891,
          "store_id": 90845675795,
          "product_id": 9711268495635,
          "title": "Dawn",
          "option1": "Dawn",
          "option2": null,
          "option3": null,
          "image": null,
          "inventory": 10,
          "inventory_management": "shopify",
          "price": 700,
          "compare_at_price": null,
          "created_at": "2024-10-17T06:17:10.000000Z",
          "updated_at": "2024-10-17T06:17:10.000000Z"
      },
      {
          "id": 49928935440659,
          "store_id": 90845675795,
          "product_id": 9711268495635,
          "title": "Powder",
          "option1": "Powder",
          "option2": null,
          "option3": null,
          "image": null,
          "inventory": 10,
          "inventory_management": "shopify",
          "price": 700,
          "compare_at_price": null,
          "created_at": "2024-10-17T06:17:10.000000Z",
          "updated_at": "2024-10-17T06:17:10.000000Z"
      },
      {
          "id": 49928935473427,
          "store_id": 90845675795,
          "product_id": 9711268495635,
          "title": "Electric",
          "option1": "Electric",
          "option2": null,
          "option3": null,
          "image": null,
          "inventory": 10,
          "inventory_management": "shopify",
          "price": 700,
          "compare_at_price": null,
          "created_at": "2024-10-17T06:17:10.000000Z",
          "updated_at": "2024-10-17T06:17:10.000000Z"
      },
      {
          "id": 49928935506195,
          "store_id": 90845675795,
          "product_id": 9711268495635,
          "title": "Sunset",
          "option1": "Sunset",
          "option2": null,
          "option3": null,
          "image": null,
          "inventory": 10,
          "inventory_management": "shopify",
          "price": 700,
          "compare_at_price": null,
          "created_at": "2024-10-17T06:17:10.000000Z",
          "updated_at": "2024-10-17T06:17:10.000000Z"
      }
  ],
  "options": [
      {
          "id": 12173539639571,
          "store_id": 90845675795,
          "product_id": 9711268495635,
          "name": "Color",
          "values": [
              "Ice",
              "Dawn",
              "Powder",
              "Electric",
              "Sunset"
          ],
          "created_at": "2024-10-17T06:17:11.000000Z",
          "updated_at": "2024-10-17T06:17:11.000000Z"
      }
  ]
}

export const _product3 = {
  "id": 9711268528403,
  "store_id": 90845675795,
  "title": "The Hidden Snowboard",
  "handle": "the-hidden-snowboard",
  "image": "https://cdn.shopify.com/s/files/1/0908/4567/5795/files/Main_c8ff0b5d-c712-429a-be00-b29bd55cbc9d.jpg?v=1729080387",
  "price": 750,
  "compare_at_price": null,
  "available": "1",
  "stock": 50,
  "inventory_management": "shopify",
  "status": "active",
  "requires_selling_plan": 0,
  "created_at": "2024-10-16T12:06:27.000000Z",
  "updated_at": "2024-10-17T06:17:10.000000Z",
  "variants": [
      {
          "id": 49928935538963,
          "store_id": 90845675795,
          "product_id": 9711268528403,
          "title": "Default Title",
          "option1": "Default Title",
          "option2": null,
          "option3": null,
          "image": null,
          "inventory": 50,
          "inventory_management": "shopify",
          "price": 750,
          "compare_at_price": null,
          "created_at": "2024-10-17T06:17:10.000000Z",
          "updated_at": "2024-10-17T06:17:10.000000Z"
      }
  ],
  "options": [
      {
          "id": 12173539672339,
          "store_id": 90845675795,
          "product_id": 9711268528403,
          "name": "Title",
          "values": [
              "Default Title"
          ],
          "created_at": "2024-10-17T06:17:11.000000Z",
          "updated_at": "2024-10-17T06:17:11.000000Z"
      }
  ]
}

export const _product4 = {
  "id": 9711268593939,
  "store_id": 90845675795,
  "title": "The Inventory Not Tracked Snowboard",
  "handle": "the-inventory-not-tracked-snowboard",
  "image": "https://cdn.shopify.com/s/files/1/0908/4567/5795/files/snowboard_purple_hydrogen.png?v=1729080387",
  "price": 950,
  "compare_at_price": null,
  "available": "1",
  "stock": 0,
  "inventory_management": null,
  "status": "active",
  "requires_selling_plan": 0,
  "created_at": "2024-10-16T12:06:27.000000Z",
  "updated_at": "2024-10-17T06:17:10.000000Z",
  "variants": [
      {
          "id": 49928935571731,
          "store_id": 90845675795,
          "product_id": 9711268593939,
          "title": "Default Title",
          "option1": "Default Title",
          "option2": null,
          "option3": null,
          "image": null,
          "inventory": 0,
          "inventory_management": null,
          "price": 950,
          "compare_at_price": null,
          "created_at": "2024-10-17T06:17:10.000000Z",
          "updated_at": "2024-10-17T06:17:10.000000Z"
      }
  ],
  "options": [
      {
          "id": 12173539705107,
          "store_id": 90845675795,
          "product_id": 9711268593939,
          "name": "Title",
          "values": [
              "Default Title"
          ],
          "created_at": "2024-10-17T06:17:11.000000Z",
          "updated_at": "2024-10-17T06:17:11.000000Z"
      }
  ]
}

export const _product5 = {
    "id": 97112685931939,
    "store_id": 90845675795,
    "title": "The Inventory Bon Bon ",
    "handle": "the-inventory-not-tracked-snowboard",
    "image": "https://ltd-ms-l1.myshopify.com/cdn/shop/files/Main_0a4e9096-021a-4c1e-8750-24b233166a12.jpg?v=1729080388",
    "price": 22950,
    "compare_at_price": null,
    "available": "1",
    "stock": 0,
    "inventory_management": null,
    "status": "active",
    "requires_selling_plan": 0,
    "created_at": "2024-10-16T12:06:27.000000Z",
    "updated_at": "2024-10-17T06:17:10.000000Z",
    "variants": [
        {
            "id": 49928935571731,
            "store_id": 90845675795,
            "product_id": 9711268593939,
            "title": "Default Title",
            "option1": "Default Title",
            "option2": null,
            "option3": null,
            "image": null,
            "inventory": 0,
            "inventory_management": null,
            "price": 22950,
            "compare_at_price": null,
            "created_at": "2024-10-17T06:17:10.000000Z",
            "updated_at": "2024-10-17T06:17:10.000000Z"
        }
    ],
    "options": [
        {
            "id": 12173539705107,
            "store_id": 90845675795,
            "product_id": 9711268593939,
            "name": "Title",
            "values": [
                "Default Title"
            ],
            "created_at": "2024-10-17T06:17:11.000000Z",
            "updated_at": "2024-10-17T06:17:11.000000Z"
        }
    ]
  }