export const _listCurrencySupportShopify = {
  USD: {
    name: "United States Dollar",
    code: "USD",
    symbol: "$",
    display_type: ",",
    flag: "us",
    short_format: "${{amount}}",
    explicit_format: "${{amount}} USD",
    decimal: 2,
    round: 1
  },
  EUR: {
    name: "Euro",
    code: "EUR",
    symbol: "€",
    display_type: ",",
    flag: "eur",
    short_format: "€{{amount}}",
    explicit_format: "€{{amount}} EUR",
    decimal: 2,
    round: 0.95
  },
  JPY: {
    name: "Japanese Yen",
    code: "JPY",
    symbol: "¥",
    display_type: ",",
    flag: "gb",
    short_format: "¥{{amount}}",
    explicit_format: "¥{{amount}} JPY",
    decimal: 0,
    round: 100
  },
  CAD: {
    name: "Canadian Dollar",
    code: "CAD",
    symbol: "$",
    display_type: ",",
    flag: "cad",
    short_format: "${{amount}}",
    explicit_format: "${{amount}} CAD",
    decimal: 2,
    round: 1
  },
  AUD: {
    name: "Australian Dollar",
    code: "AUD",
    symbol: "$",
    display_type: ",",
    flag: "au",
    short_format: "${{amount}}",
    explicit_format: "${{amount}} AUD",
    decimal: 2,
    round: 1
  },
  NZD: {
    name: "New Zealand Dollar",
    code: "NZD",
    symbol: "$",
    display_type: ",",
    flag: "nz",
    short_format: "${{amount}}",
    explicit_format: "${{amount}} NZD",
    decimal: 2,
    round: 1
  },
  SGD: {
    name: "Singapore Dollar",
    code: "SGD",
    symbol: "$",
    display_type: ",",
    flag: "sg",
    short_format: "${{amount}}",
    explicit_format: "${{amount}} SGD",
    decimal: 2,
    round: 1
  },
  HKD: {
    name: "Hong Kong Dollar",
    code: "HKD",
    symbol: "$",
    display_type: ",",
    flag: "hk",
    short_format: "${{amount}}",
    explicit_format: "HK${{amount}}",
    decimal: 2,
    round: 1
  },
  GBP: {
    name: "British Pound Sterling",
    code: "GBP",
    symbol: "£",
    display_type: ",",
    flag: "gb",
    short_format: "£{{amount}}",
    explicit_format: "£{{amount}} GBP",
    decimal: 2,
    round: 1
  }
}