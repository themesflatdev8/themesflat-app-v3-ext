import '@/utils/hbs';
import { fetchVariants } from "@/shared/variants"
import BundleCartPage from "@/features/bundle/cart"
import BundleProductPage from "@/features/bundle/product"

export default class Bundle {
  constructor() {
    this.init()
  }

  init(){
    let variants = fetchVariants()
    if(shopifyMSell.pageType == "product"){
      new BundleProductPage(variants)
    }
  
    new BundleCartPage(variants)
  }
}
(async function() {

  new Bundle()

})();