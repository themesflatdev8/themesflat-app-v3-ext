import '@/utils/hbs';
import { loadScript } from "@/shared/load-script"
import SwiperComponent from "@/components/swiper"
import CountdownTimerComponent from "@/components/countdown-timer"

var countLoadFunction = 0;

(async function() {

  refetchInit()
    
})();

function refetchInit(){
  if(typeof(shopifyMSell) == "undefined"){
    if(countLoadFunction <= 20){
      setTimeout(() => {
        refetchInit()
        countLoadFunction += 1;
      }, 500)
    }
  }else{
    init()
  }
}

async function init(){
  let isBundle = (typeof(shopifyMSellAppEmbed) != "undefined" && shopifyMSellAppEmbed) || typeof(shopifyMSellBundle) != "undefined" && shopifyMSellBundle 
  let isVolumeDiscount = typeof(shopifyMSellAppEmbed) != "undefined" && shopifyMSellAppEmbed && shopifyMSell.pageType == "product"
  
  addCustomElements()

  loadScript({ isBundle, isVolumeDiscount })
}

function addCustomElements(){
  customElements.define('msell-swiper', SwiperComponent);
  customElements.define('msell-countdown-timer', CountdownTimerComponent);
}